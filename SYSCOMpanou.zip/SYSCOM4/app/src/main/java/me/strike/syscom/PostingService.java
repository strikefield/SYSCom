package me.strike.syscom;
import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class PostingService extends AppCompatActivity {

    private ProgressBar pd;
    private Button posting;
    private FirebaseAuth fAuth;
    private FirebaseFirestore fStore;
    ImageView imageIv;
    private EditText inputTitle, inputTypeService, inputDateService, inputFeeService, inputDes;
    String userID;
    DatabaseReference userDbRef;
    StorageReference storageReference;
    private static final String TAG = "TAG";
    String name, email, userid, phonenumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        EditText editViewDate = findViewById(R.id.dateOfPost);
        editViewDate.setText(currentDate);

        inputTitle = (EditText) findViewById(R.id.title);
        inputTypeService = (EditText) findViewById(R.id.typeOfService);
        inputDateService = (EditText) findViewById(R.id.dateOfPost);
        inputFeeService = (EditText) findViewById(R.id.feeOfService);
        inputDes = (EditText) findViewById(R.id.description);
        imageIv =findViewById(R.id.imageView);
        posting = (Button) findViewById(R.id.posting_btn);
        pd = (ProgressBar) findViewById(R.id.progressBar);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        pd= new ProgressBar(this);


        userDbRef = FirebaseDatabase.getInstance().getReference("PostService");
        Query query = userDbRef.orderByChild("email").equalTo(email);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren()){
                    name = "" + ds.child("name").getValue();
                    email = "" + ds.child("email").getValue();
                    phonenumber = "" + ds.child("phone number").getValue();

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        storageReference = FirebaseStorage.getInstance().getReference();


        StorageReference profileRef  = storageReference.child("users/"+fAuth.getCurrentUser().getUid()+"/profile.jpg");
        profileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(imageIv);
            }
        });


        posting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String aDateService = inputDateService.getText().toString();
                String aFeeService = inputFeeService.getText().toString();
                String title = inputTitle.getText().toString().trim();
                String typeService = inputTypeService.getText().toString().trim();
                String description = inputDes.getText().toString().trim();


                if(TextUtils.isEmpty(title)){
                    Toast.makeText(PostingService.this, "Enter the title", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(typeService)){
                    Toast.makeText(PostingService.this, "Enter the type of service", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(aDateService)){
                    Toast.makeText(PostingService.this, "Enter the date", Toast.LENGTH_SHORT).show();
                    return;

                }
                if(TextUtils.isEmpty(aFeeService)){
                    Toast.makeText(PostingService.this, "Enter the fee service", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(description)){
                    Toast.makeText(PostingService.this, "Enter the description", Toast.LENGTH_SHORT).show();
                    return;

                }
                updateData(title, typeService, aDateService,aFeeService, description);

//                userID = fAuth.getCurrentUser().getUid();
//                DocumentReference documentReference = fStore.collection("Post").document(userID);
//                Map<String, Object> service = new HashMap<>();
//                service.put("Title", Title);
//                service.put("TypeService", TypeService);
//                service.put("DateService", aDateService);
//                service.put("FeeService", aFeeService);
//                service.put("Description", Description);
//                documentReference.set(service).addOnSuccessListener(new OnSuccessListener<Void>() {
//                    @Override
//                    public void onSuccess(Void aVoid) {
//                        Log.d(TAG,"onSuccess: Post is created for " + userID);
//                    }
//                });
            }
        });
    }
    private void updateData(String title, String typeService, String aDateService, String aFeeService, String description){


        String timeStamp = String.valueOf((System.currentTimeMillis()));
        String filePathAndName = "Post/" + "post" + timeStamp;
        StorageReference profileRef  = FirebaseStorage.getInstance().getReference().child(filePathAndName);
        Map<String, Object> service = new HashMap<>();
        service.put("Title", title);
        service.put("TypeService", typeService);
        service.put("DateService", aDateService);
        service.put("FeeService", aFeeService);
        service.put("Description", description);
        service.put("Name" , name);
        service.put("Email", email);
        service.put("PhoneNumber", phonenumber);

        DatabaseReference ref =FirebaseDatabase.getInstance().getReference("PostService");
        ref.child(timeStamp).setValue(service);
    }

    public void logout(View view) {
        startActivity(new Intent(getApplicationContext(),MainActivity.class));
        finish();
    }

}