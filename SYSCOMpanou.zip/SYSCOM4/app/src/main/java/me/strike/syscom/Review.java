package me.strike.syscom;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class Review extends AppCompatActivity {
    private ProgressBar progressBar;
    private Button submit;
    private FirebaseAuth fAuth;
    private FirebaseFirestore fStore;
    private EditText inputName, inputFeedback, dateReview;
    String userID;
    StorageReference storageReference;
    private static final String TAG = "TAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        EditText editViewDate = findViewById(R.id.dateReview);
        editViewDate.setText(currentDate);

        inputName = (EditText) findViewById(R.id.name);
        inputFeedback = (EditText) findViewById(R.id.feedback);
        dateReview = (EditText) findViewById(R.id.dateReview);
        submit = (Button) findViewById(R.id.review_btn);
        //progressBar = (ProgressBar) findViewById(R.id.progressBar);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();



        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = inputName.getText().toString();
                String feedback = inputFeedback.getText().toString();
                String date = dateReview.getText().toString().trim();

                userID = fAuth.getCurrentUser().getUid();
                DocumentReference documentReference = fStore.collection("Review").document(userID);
                Map<String, Object> review = new HashMap<>();
                review.put("Name", name);
                review.put("Feedback", feedback);
                review.put("DateReview", date);

                documentReference.set(review).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "onSuccess: Review is created for " + userID);
                    }
                });
            }
            public void logout (View view){
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                finish();
            }
        });
    }
}
